package com.edu;

import java.sql.*;

public class DatabaseConnection {

	public static Connection con;
	public static Connection getconnection() throws Exception {
		
		Class.forName("com.mysql.cj.jdbc.Driver");
		con=DriverManager.getConnection("jdbc:mysql://localhost:3306/bankdb","root","root");
		if(con==null) {
			System.out.println("Error in getting connection");
		}
		return con;
		
	}

}
