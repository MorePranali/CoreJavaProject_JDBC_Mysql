package com.edu;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Scanner;

public class TransactionOperations {
	
	 static Connection con;
     static PreparedStatement psd,psd2;
     static   ResultSet rs,rs2;
     static String s;

	
	//*****Deposit Amount method
	public static void depositeAmount() throws Exception {
		
            con=DatabaseConnection.getconnection();
            String ACNo,Tno,Tdate,Tmedium,Ttype;
            int Tamount;
            
            Scanner sc=new Scanner(System.in);
    		System.out.println("Enter Account Number For transaction:");
    		ACNo=sc.next();
    		
    		PreparedStatement psd;
    		s="Select * from Account where AccountNo=?";
    		psd=con.prepareStatement(s);
    		psd.setString(1, ACNo);
    		ResultSet rs=psd.executeQuery();
    		if(rs.next()) {
    			    System.out.println("Enter Date:(yyyy-mm-dd)");
    	            Tdate=sc.next();
    	            System.out.println("Enter medium of transation (Cash/Check):");
  		            Tmedium=sc.next();
  		            System.out.println("Enter Type of transation (Deposit/Withdraw):");
    		        Ttype=sc.next();
     	            System.out.println("Enter Amount of trnasation :");
		            Tamount=sc.nextInt();
		            
    	  String ins="insert into TransDetails (AccountNo,TransDate,mediumOfTrans,TransType,Trans_Amount) values(?,?,?,?,?)";
    		  	      psd=con.prepareStatement(ins);
    		  	      psd.setString(1, ACNo);
    		          psd.setString(2, Tdate);
    		  	      psd.setString(3, Tmedium);
    	              psd.setString(4, Ttype);
    		  	      psd.setInt(5, Tamount);
    		  	         if(Tamount>0) {
    		  	        	 int i=psd.executeUpdate();
  	    		  	          if(i>0) {
    		  	                	String type="Select TransType from TransDetails where AccountNo=?";
    		  	                	psd=con.prepareStatement(type);
    		  			    		psd.setString(1,ACNo);
    		  			    		ResultSet rs2=psd.executeQuery();
    		  			    		if(rs2.next()) {
    		  			    			String Transtype=rs2.getString("TransType");
    		  			    		//	System.out.println("Transaction type="+Transtype);
    		  			    			
    		  			    			if(Transtype.equals(Ttype)) {
    		  			    			
    		  	                	String bal="Select Opening_Bal from Account where AccountNo=?";
    		  			    		psd=con.prepareStatement(bal);
    		  			    		psd.setString(1,ACNo);
    		  			    		ResultSet rs3=psd.executeQuery();
    		  			    		if(rs3.next()) {
    		  			    			int Balance=rs3.getInt("Opening_Bal");
    		  			    			Balance =Balance + Tamount;
    		  			    			System.out.println("Total balace="+Balance);
    		  			    			
    		  			    			String upd="update Account set Opening_Bal=? where AccountNo=?";
    		  			    			psd=con.prepareStatement(upd);
	    		  			    		psd.setInt(1,Balance);
	    		  			    		psd.setString(2,ACNo);
	    		  			    		int i1=psd.executeUpdate();
	    		  			    		   if(i>0) {
    		  			    			        System.out.println("Deposite Amount Successfull!!");
	    		  			    		   } else {
	    		  			    			  System.out.println("Error occured!!!"); 
	    		  			    		   }
    		  			    		    }
    		  	                	 }
    			           
    		  			    		}
    			            
    		  	                	}
  		  	                	
    			             }else {
		  	                		System.out.println("please Enter deposite amount in correct way.");
    			             }
	
		
    		}
	
	}	//end deposite method
	
	
	
	
	
	//*****Withdraw Amount method
	public static void withdrawAmount() throws Exception {
		
            con=DatabaseConnection.getconnection();
            String ACNo,Tno = null,Tdate,Tmedium,Ttype;
            int Tamount;
            
            Scanner sc=new Scanner(System.in);
    		System.out.println("Enter Account Number For transaction:");
    		ACNo=sc.next();
    		
    		PreparedStatement psd;
    		String s="Select * from Account where AccountNo=?";
    		psd=con.prepareStatement(s);
    		psd.setString(1, ACNo);
    		ResultSet rs=psd.executeQuery();
    		if(rs.next()) {
			      System.out.println("Enter Date:(yyyy-mm-dd)");
    			  Tdate=sc.next();
                  System.out.println("Enter medium of transation (Cash/Check):");
    			  Tmedium=sc.next();
    	          System.out.println("Enter Type of transation (Deposit/Withdraw):");
    			  Ttype=sc.next();
    			  System.out.println("Enter Amount of trnasation :");
    			  Tamount=sc.nextInt();
    	
    String ins="insert into TransDetails (AccountNo,TransDate,mediumOfTrans,TransType,Trans_Amount) values(?,?,?,?,?)"; 
    	          psd=con.prepareStatement(ins);           
    		  	  psd.setString(1, ACNo);
                  psd.setString(2, Tdate);
                  psd.setString(3, Tmedium);
                  psd.setString(4, Ttype);
                  psd.setInt(5, Tamount);
                  
                  if(Tamount>0) {
    		  	            int i=psd.executeUpdate();
    		  	            if(i>0) {
    		  	                	String type="Select TransType from TransDetails where TransType=?";
    		  	                	psd=con.prepareStatement(type);
    		  			    		psd.setString(1,Ttype);
    		  			    		ResultSet rs2=psd.executeQuery();
    		  			    		if(rs2.next()) {
    		  			    			String Transtype=rs2.getString("TransType");
    		  			    		//	System.out.println("Transaction type="+Transtype);
    		  			    			
    		  			    		if(Transtype.equals(Ttype)) {
    		  			    			
    		  	                	String bal="Select Opening_Bal from Account where AccountNo=?";
    		  			    		psd=con.prepareStatement(bal);
    		  			    		psd.setString(1,ACNo);
    		  			    		ResultSet rs3=psd.executeQuery();
    		  			    		if(rs3.next()) {
    		  			    			int Balance=rs3.getInt("Opening_Bal");
    		  			    			if(Balance>Tamount) {
    		  			    		         	Balance =Balance - Tamount;
    		  			    			        System.out.println("Total balace="+Balance);
    		  			    			
    		  			    			        String upd="update Account set Opening_Bal=? where AccountNo=?";
    		  			    		         	psd=con.prepareStatement(upd);
	    		  			    		        psd.setInt(1,Balance);
	    		  			    		        psd.setString(2,ACNo);
	    		  			    		        int i1=psd.executeUpdate();
	    		  			    		        if(i>0) {
    		  			    			              System.out.println("Withdraw Amount Successfull!!");
	    		  			    		             }  
    		  			    			}else {
    		  			    				System.out.println("Insufifcient balance");
    		  			    				String del="delete from TransDetails where TransDate=?";
		    		  	                	psd=con.prepareStatement(del);
		    		  			    		psd.setString(1,Tdate);
		    		  			    		int i2=psd.executeUpdate();
    		  			    			 }
    		  			    		    }
    		  	                	  }
    		  			    		}
    		  	                }
    		  	            
    		  	           }else {
		  	                	System.out.println("please Enter withdraw amount in correct way.");	
	  			    		}
    		}
    	
	  }  //end withdraw method
	
		


}
