package com.edu;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.*;
import java.util.Scanner;


    public class ReportOfBankApplication {
 
    	        static  Connection con;

	            public static void Reports() throws Exception {
		
	            	int ch;
	        		String ACNo;
	        		
	        	    con =DatabaseConnection.getconnection();
	        		PreparedStatement psd;
	        	    String s;
	        		Scanner sc=new Scanner(System.in);
	        		System.out.println("***** Reports Bank Application Core Project ******");
	        		while(true) {
	        			System.out.println("1.Check balance");
	        			System.out.println("2.Check Transaction History");
	        			System.out.println("3.Exit and go to main module");
	        			System.out.println("please enter choice for showing report :");
	        			ch=sc.nextInt();
	        			switch(ch) {      
	        			case 1:
	        				System.out.println("Enter Account Number :");
	        				ACNo=sc.next();
	        	s="select ah.FName,ah.LName ,a.accountNo,a.opening_Bal from AccountHolder ah inner join Account a where ah.userId=a.userId and  AccountNo=?";
	        			  //  s="Select * from Account where AccountNo=?";
	        	    		psd=con.prepareStatement(s);
	        	    		psd.setString(1, ACNo);
	        	    		ResultSet rs=psd.executeQuery();
	        	    		System.out.println("FName\tLName\tA/CNo\tBalance");
	        	    		System.out.println("==============================");
	        	    		if(rs.next()) {
	        	    			System.out.println(rs.getString("FName")+"\t"+rs.getString("LName")+"\t"+rs.getString("AccountNo")+"\t"+rs.getInt("Opening_Bal")+"\t");	
	        			     }
	        	    		break;
	        	    		
	        			case 2:
	        				System.out.println("Please Enter Account Number:");
	        				ACNo=sc.next().toLowerCase();
	        				s="select AccountNo,Trsno,TransDate,TransType,Trans_Amount from transdetails where AccountNo=?";
	        				psd=con.prepareStatement(s);
	        	    		psd.setString(1, ACNo);
	        	    		ResultSet rs1=psd.executeQuery();
	        	    		System.out.println("A/CNo\tTrsId\tDate\tType\tAmount");
	        	    		System.out.println("===========================================");
	        	    		while(rs1.next()) {
	        	    			System.out.println(rs1.getString("AccountNo")+"\t"+rs1.getInt("Trsno")+"\t"+rs1.getString("TransDate")+"\t"+rs1.getString("TransType")+"\t"+rs1.getInt("Trans_Amount")+"\t");	
	        			     }
	        				break;
	        				
	        			case 3:
	        				System.out.println("Close report");
	        				MainApplicationOfBank.main(null);
	
	        			} //end switch case
	        			System.out.println();
	        		}//end while loop
	     }
}
