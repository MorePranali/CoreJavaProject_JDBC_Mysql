package com.edu;

import java.util.Scanner;

public class MainApplicationOfBank {

	public static void main(String[] args) throws Exception {
		int ch,Uch,Ach;
		Scanner sc=new Scanner(System.in);
		
		System.out.println("***** Welcome in Simple Bank Application Core Project ******");
		while(true) {
			
			System.out.println("1.User Login");
			System.out.println("2.User Create Registration form");
			System.out.println("3.Admin Login");
			System.out.println("4.Exit");
			
		    System.out.println("Enter your choice:");
			ch=sc.nextInt();
			switch(ch){
			
			case 1:UserLogin.loginMethod();
        		   break;
        			
			case 2:UserLogin.registrationForm();
	        	   break;	
			
			case 3:UserLogin.adminLogin();
				   break;
				
			case 4:System.out.println("System will be terminate!!!!!");
			       System.exit(0);
                   break; 
			}
			         
	         System.out.println("Do you want to continue n to stop any other key to continue");
	         char choice=sc.next().charAt(0);
			   if(ch=='n') {
				   break;
			     }
			  } 
		

	}

}
