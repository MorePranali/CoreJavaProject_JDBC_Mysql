package com.edu;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.*;

public class UserLogin {
	
	static Scanner sc=new Scanner(System.in);
	static Connection con;
     static PreparedStatement psd;
     static   ResultSet rs;
	static String s;
	
	public static void loginMethod() throws Exception {
		 con=DatabaseConnection.getconnection();
		
		 System.out.println("Enter UserName:");
	     String username=sc.next();
	     System.out.println("Enter Password:");
	     String pass=sc.next();
	     s="select * from Userlogin where Uname=? and Upass=?";
	     psd=con.prepareStatement(s);
 		psd.setString(1, username);
 		psd.setString(2, pass);
 	    rs=psd.executeQuery();
 	    
 	 
 	    if(rs.next()) {
 	    	
 	    	System.out.println("Login successfully !!!!!");
 	    	System.out.println("=================================");
 	    	 while(true) {
 	    	System.out.println("**** Welcome in User Module *****");
 	    	System.out.println("1.Deposite Amount");
			System.out.println("2.Withdraw Amount");
			System.out.println("3.Reports");
			System.out.println("4.Quit and go to back");
			System.out.println("What operation you want to do? so please enter choice :");
			int Uch=sc.nextInt();
			
			switch(Uch) {
		           
                      case 1:TransactionOperations.depositeAmount();
                             break; 
                      case 2: TransactionOperations.withdrawAmount();
                              break;
                      case 3: ReportOfBankApplication.Reports();
                              break;
                      case 4:MainApplicationOfBank.main(null);
                             break;         
			}
			System.out.println("Do you want to perform other operatios 'n' to stop any other key to continue:");
		       char choice=sc.next().charAt(0);
				   if(Uch=='n') {
					   break;
				     }
			}
 	    	
 	    }else {
 	    	System.out.println("Invalid Username and password");
 	    }
 	   
		
	}

	public static void registrationForm() throws Exception {
		
		BankApplicationOperation.registrationForm();
	}

	public static void adminLogin() throws Exception {
		 con=DatabaseConnection.getconnection();
			
		 System.out.println("Enter AdminName:");
	     String adminname=sc.next();
	     System.out.println("Enter Password:");
	     String pass=sc.next();
	     s="select * from Adminlogin where Aname=? and Apass=?";
	     psd=con.prepareStatement(s);
 		psd.setString(1, adminname);
 		psd.setString(2, pass);
 	    rs=psd.executeQuery();
 	    if(rs.next()) {
 	    	
 	    	System.out.println("**** Welcome in Admin Module *****");
			System.out.println("1.Create Account");
			System.out.println("2.Delete Account");
			System.out.println("3.Quit and go to back");
			
			System.out.println("What operation you want to do? so please enter choice :");
			 int Ach=sc.nextInt();
	     	
			switch(Ach){
		                  case 1:BankApplicationOperation.createAccount();
                                 break; 
		                  case 2: BankApplicationOperation.deleteAccount();
                                 break;
		                  case 3:MainApplicationOfBank.main(null);
                           break;       
			}		
        	
 	    }else {
 	    	System.out.println("Invalid Adminname and password..");
 	    }
		
		
	}


}
