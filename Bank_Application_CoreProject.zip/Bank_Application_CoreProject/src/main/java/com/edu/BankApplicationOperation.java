package com.edu;

import java.sql.*;
import java.util.Scanner;

public class BankApplicationOperation {
	
	         static Connection con;
	         static PreparedStatement psd,psd2;
	         static   ResultSet rs,rs2;
	         static  String s,s1;
	   
	
	        //****Create User Registration method
	         public static void registrationForm() throws Exception {
		            con=DatabaseConnection.getconnection();
		            int UserId;
		            String FirstName,LastName,City,MobNo,Occupation,DOB,pass;
		            
		            Scanner sc=new Scanner(System.in);
		    		System.out.println("Enter UserId to be Registration form :");
		    		UserId=sc.nextInt();
		    		
		    		 s="select * from AccountHolder where userId=?";
		    		psd=con.prepareStatement(s);
		    		psd.setInt(1, UserId);
		    	    rs=psd.executeQuery();
		    		
		    		if(!rs.next()) { 
		    			System.out.println("Enter User First Name:");
		    			FirstName=sc.next();
		    			System.out.println("Enter Last Name:");
		    			LastName=sc.next();
		    			System.out.println("Enter City:");
		    			City=sc.next();
		    			System.out.println("Enter Mobile Number:");
		    			MobNo=sc.next();
		    			System.out.println("Enter Occupation:");
		    			Occupation=sc.next();
		    			System.out.println("Enter User date of birth (yyyy-mm-dd):");
		    			DOB=sc.next();
		    			System.out.println("Enter Password:");
		    			pass=sc.next();
		    			
	  	                 s="insert into AccountHolder values(?,?,?,?,?,?,?,?)";
	  	                psd=con.prepareStatement(s);
	  	                psd.setInt(1, UserId);
	  	                psd.setString(2, FirstName);
	  	                psd.setString(3, LastName);
	  	                psd.setString(4, City);
	  	                psd.setString(5, MobNo);
	  	                psd.setString(6, Occupation);
	  	                psd.setString(7, DOB);
	  	                psd.setString(8,pass);
	  	                
	  	                int i=psd.executeUpdate();
	  	                if(i>0) {
	  	                	System.out.println("Create Bank Account Successfully!!!!!");
	  	                	
	  	                	s= "insert into userlogin values(?,?,?)";
	  	                	psd=con.prepareStatement(s);
	 	  	                psd.setString(1, FirstName);
	 	  	                psd.setString(2, pass);
	 	  	                psd.setInt(3,UserId);
	 	  	                 psd.executeUpdate();
	 	  	           //  System.out.println("insert into login table "); 	
	  	                }else {
	  	            	   System.out.println("Error occured !!"); 
	  	         	     }
	  	                
	  		    	}else {
	  				        System.out.println("User is already exist in AccountHolder table");
	  		     	    }	
	  	                
	         }
	         
	         
             //****Create Bank Account Method
			public static void createAccount() throws Exception {
				    con=DatabaseConnection.getconnection();
		            int UserId,OpenBal ;
		            String BankId,ACNo,Adate,Atype;
		            
		            Scanner sc=new Scanner(System.in);
		    		System.out.println("Enter User Id to be Create Bank Account:");
		    		UserId=sc.nextInt();
		    		System.out.println("Bank of Maharashtra:B101");
		    		System.out.println("Enter Bank Id to be check Bank Name:");
		    		BankId=sc.next();
		    		
		    	    s="select * from AccountHolder where userId=?";
		    	    s1="select * from BankBranch where bId=?";
		    		psd=con.prepareStatement(s);
		    		psd2=con.prepareStatement(s1);
		    		psd.setInt(1, UserId);
		    		psd2.setString(1, BankId);
		    	    rs=psd.executeQuery();
		    		rs2=psd2.executeQuery();
		    		
		    		if(rs.next()) {
		    			if(rs2.next()) {
		    			       System.out.println("Enter Account Number in form XX201:");
		    			       ACNo=sc.next();
		    			       PreparedStatement psd1;
		   		    		    s="select * from Account where AccountNo=?";
		   		    		   psd1=con.prepareStatement(s);
		   		    		   psd1.setString(1, ACNo);
		   		    		   ResultSet rs1=psd1.executeQuery();
		   		    		   if(!rs1.next()) {
		    			         System.out.println("Enter opening Balance Amount:");
		    			         OpenBal=sc.nextInt();
		    			         System.out.println("Enter Date:(yyyy-mm-dd)");
		    			         Adate=sc.next();
		    			         System.out.println("Enter Account type:(saving or current)");
		    	                 Atype=sc.next();
		    			        s="insert into Account values(?,?,?,?,?,?)";
			  	                psd=con.prepareStatement(s);
			  	                psd.setString(1,ACNo);
			  	                psd.setInt(2,UserId);
			  	                psd.setString(3,BankId);
			  	                psd.setInt(4,OpenBal);
			  	                psd.setString(5,Adate);
			  	                psd.setString(6,Atype);
			  	                if(OpenBal>500) {
			  	                int i=psd.executeUpdate();
			  	                     if(i>0) {
			  	                            System.out.println("Create Account Successfully!!!!!");
			  	                      }else {
			  	                	        System.out.println("Error Occured!!");
			  	                        }
		   		    		   } else {
		   		    			   System.out.println("opening balance should be a greater 500");
		   		    		   }
		   		    		   }else {
		   		    			   System.out.println("Already Account is Created!!");
		   		    		   }
		    			}
		    		}else {
		    			System.out.println("Please, fill the registration form");	
		    		}
		    		
				}

			
			//*********delete User account
			public static void deleteAccount() throws Exception {
				 con=DatabaseConnection.getconnection();
		            int UserId;
		            String acno;
		            Scanner sc=new Scanner(System.in);
		            System.out.println("Enter Account No to deleted:");
		            acno=sc.next();
		    		String s="select * from Account where AccountNo=?";
		    		psd=con.prepareStatement(s);
		    		psd.setString(1, acno);
		    	    rs=psd.executeQuery();
		    	    if(rs.next()) { 
		    	    	String s1="delete from transdetails where AccountNo=?";
		    	    	psd=con.prepareStatement(s1);
			    		psd.setString(1, acno);
			     	    int i=psd.executeUpdate();
			     	       if(i>0) {
			     		       System.out.println("delete transId successfully!!!!");
			     	         }
		    	    	String del="delete from Account where AccountNo=?";
			        	psd=con.prepareStatement(del);
			    		psd.setString(1, acno);
			     	    int i2=psd.executeUpdate();
			     	       if(i2>0) {
			     		       System.out.println("delete account successfully!!!!");
			     	         }
		    	    }else {
		    	    	System.out.println("Account no does not exist");
		    	    }
		    	    
		    		System.out.println("Enter UserId to be Registration form :");
		    		UserId=sc.nextInt();
		    		String s1="select * from AccountHolder where userId=?";
		    		psd=con.prepareStatement(s1);
		    		psd.setInt(1, UserId);
		    	    rs=psd.executeQuery();
			    		
			        if(rs.next()) {
			        	
			        	String s2="delete from userlogin where userId=?";
			        	psd=con.prepareStatement(s2);
			    		psd.setInt(1, UserId);
			     	    int i4=psd.executeUpdate();
			     	       if(i4>0) {
			     		       System.out.println("delete login creadantion successfully!!!!");
			     		       
			     	         }
			        	String del1="delete from AccountHolder where userId=?";
			        	psd=con.prepareStatement(del1);
			    		psd.setInt(1, UserId);
			     	    int i3=psd.executeUpdate();
			     	       if(i3>0) {
			     		       System.out.println("delete userId successfully!!!!");
			     		       
			     	         }
			        }else {
			                System.out.println("entered userId does not exist in a system");
			              }
			        	
				
			}


			

}
